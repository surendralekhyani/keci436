<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		.vertical-center {
			margin: 0;
			position: absolute;
			top: 35%;
			left: 50%;
			-ms-transform: translateY(-50%);
			transform: translateY(-50%);
			-ms-transform: translateX(-50%);
			transform: translateX(-50%);
		}
	</style>
</head>
<body>
	<div style="text-align:center; height:80vh;">
	<div class="vertical-center">
		<img src="<?php echo base_url(); ?>/public/images/logo.png" alt="" width="250px">
	</div>
	</div>
</body>
</html>